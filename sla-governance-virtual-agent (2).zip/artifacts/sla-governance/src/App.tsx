import { type FormEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  BarChart3,
  Bot,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleDot,
  ClipboardCheck,
  Clock3,
  FileText,
  LayoutDashboard,
  Menu,
  MessageSquare,
  Plus,
  RefreshCw,
  Send,
  Settings2,
  ShieldCheck,
  Trash2,
  UserRound,
  X,
} from 'lucide-react';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import NotFound from '@/pages/not-found';

type Incident = {
  number: string;
  desc: string;
  priority: number;
  group: string;
  assignee: string;
  elapsed: number;
  state: string;
};

type Justification = {
  incident: string;
  reason: string;
  explanation: string;
  submittedBy: string;
  review: string;
};

type DemoData = { next: number; incidents: Incident[]; justifications: Justification[] };
type Message = { id: number; role: 'assistant' | 'user'; text: string; links?: { label: string; href: string }[] };

const SLA_HOURS = 4;
const RISK_THRESHOLD = 75;
const DATA_KEY = 'slaDemoData';
const CHAT_KEY = 'slaDemoConversation';

const DEFAULT_DATA: DemoData = {
  next: 1006,
  incidents: [
    { number: 'INC0010001', desc: 'Critical production application issue', priority: 1, group: 'Application Support', assignee: 'Alex', elapsed: 3.2, state: 'In Progress' },
    { number: 'INC0010002', desc: 'Production database outage', priority: 1, group: 'Database Team', assignee: 'Priya', elapsed: 4.6, state: 'In Progress' },
    { number: 'INC0010003', desc: 'Email notification issue', priority: 2, group: 'Service Desk', assignee: 'Rahul', elapsed: 1.4, state: 'In Progress' },
    { number: 'INC0010004', desc: 'Payment service degradation', priority: 1, group: 'Application Support', assignee: 'Demo User', elapsed: 2.6, state: 'In Progress' },
    { number: 'INC0010005', desc: 'User access request', priority: 3, group: 'Service Desk', assignee: 'Demo User', elapsed: 1.0, state: 'Resolved' },
  ],
  justifications: [
    { incident: 'INC0010002', reason: 'Technical Complexity', explanation: 'Investigation required additional technical analysis before the production database issue could be isolated.', submittedBy: 'SLA User', review: 'Pending' },
  ],
};

function cloneDefaults() {
  return JSON.parse(JSON.stringify(DEFAULT_DATA)) as DemoData;
}

function readData(): DemoData {
  try {
    const saved = localStorage.getItem(DATA_KEY);
    return saved ? JSON.parse(saved) as DemoData : cloneDefaults();
  } catch {
    return cloneDefaults();
  }
}

function statusOf(incident: Incident) {
  if (incident.state === 'Resolved') return { label: 'Completed', pct: 100, remaining: 0, tone: 'success' as const };
  if (incident.priority !== 1) return { label: 'Not applicable', pct: 0, remaining: null, tone: 'info' as const };
  const pct = Math.round((incident.elapsed / SLA_HOURS) * 100);
  if (pct >= 100) return { label: 'Breached', pct, remaining: incident.elapsed - SLA_HOURS, tone: 'danger' as const };
  if (pct >= RISK_THRESHOLD) return { label: 'At risk', pct, remaining: SLA_HOURS - incident.elapsed, tone: 'warning' as const };
  return { label: 'Within SLA', pct, remaining: SLA_HOURS - incident.elapsed, tone: 'success' as const };
}

function useDemoData() {
  const [data, setData] = useState<DemoData>(() => readData());
  const update = (next: DemoData) => {
    setData(next);
    localStorage.setItem(DATA_KEY, JSON.stringify(next));
  };
  return { data, update };
}

function usePageName(path: string) {
  if (path === '/') return 'Overview';
  if (path === '/chat') return 'Virtual Agent';
  if (path === '/incidents') return 'Incidents & SLA';
  if (path === '/breaches') return 'Justifications';
  return 'Dashboard';
}

function Tag({ tone, children }: { tone: 'success' | 'warning' | 'danger' | 'info' | 'neutral'; children: ReactNode }) {
  return <span className={`tag tag-${tone}`} data-testid={`status-${String(children).toLowerCase().replace(/\s/g, '-')}`}>{children}</span>;
}

function Metric({ label, value, meta, icon: Icon, tone = 'primary' }: { label: string; value: string | number; meta: string; icon: typeof Activity; tone?: 'primary' | 'danger' | 'warning' | 'success' }) {
  return (
    <div className="panel metric" data-testid={`metric-${label.toLowerCase().replace(/\s/g, '-')}`}>
      <Icon className="metric-icon" />
      <div className="metric-label">{label}</div>
      <div className={`metric-value ${tone === 'danger' ? 'text-[hsl(var(--danger))]' : tone === 'warning' ? 'text-[#9c6510]' : tone === 'success' ? 'text-[#207756]' : ''}`} data-testid={`value-${label.toLowerCase().replace(/\s/g, '-')}`}>{value}</div>
      <div className="metric-meta">{meta}</div>
    </div>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const [location, setLocation] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const page = usePageName(location);
  const navItems = [
    { href: '/', label: 'Overview', icon: LayoutDashboard },
    { href: '/chat', label: 'Virtual Agent', icon: MessageSquare },
    { href: '/incidents', label: 'Incidents & SLA', icon: Activity },
    { href: '/breaches', label: 'Justifications', icon: ClipboardCheck },
    { href: '/dashboard', label: 'Dashboard', icon: BarChart3 },
  ];
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">SLA</div>
          <div><div className="brand-title">Control Desk</div><div className="brand-subtitle">Governance workspace</div></div>
        </div>
        <div className="nav-label">Workspace</div>
        <nav className="nav-list" aria-label="Primary navigation">
          {navItems.map(({ href, label, icon: Icon }) => (
            <Link key={href} href={href} className={`nav-link ${location === href ? 'active' : ''}`} data-testid={`link-${label.toLowerCase().replace(/[^a-z]+/g, '-')}`}>
              <Icon className="nav-icon" /> <span>{label}</span>
            </Link>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div><span className="status-dot" />Demo environment online</div>
          <div style={{ marginTop: 8 }}>Local data is saved in this browser.</div>
        </div>
      </aside>
      <div className="main-area">
        <header className="topbar">
          <div className="flex items-center gap-3">
            <button className="icon-button mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Open navigation" data-testid="button-open-navigation"><Menu /></button>
            <div className="crumb"><strong>Operations</strong><ChevronRight size={13} style={{ display: 'inline', margin: '0 5px', verticalAlign: 'middle' }} />{page}</div>
          </div>
          <div className="top-actions">
            <button className="icon-button" onClick={() => setLocation('/chat')} aria-label="Open assistant" data-testid="button-open-assistant"><Bot size={16} /></button>
            <button className="icon-button" onClick={() => window.location.reload()} aria-label="Refresh demo" data-testid="button-refresh"><RefreshCw size={15} /></button>
            <div className="avatar" title="Signed in as SLA User">SU</div>
          </div>
        </header>
        {menuOpen && (
          <div className="fixed inset-x-0 top-[60px] z-30 border-b border-border bg-[#172e3c] p-3 md:hidden">
            {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} onClick={() => setMenuOpen(false)} className="flex items-center gap-2 rounded-lg px-3 py-3 text-sm text-[#dcebea]" data-testid={`mobile-link-${label.toLowerCase().replace(/[^a-z]+/g, '-')}`}><Icon size={16} />{label}</Link>)}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

function PageHeading({ eyebrow, title, subhead, action }: { eyebrow: string; title: string; subhead: string; action?: ReactNode }) {
  return <div className="page-heading"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p className="subhead">{subhead}</p></div>{action}</div>;
}

function HomePage({ data }: { data: DemoData }) {
  const risks = data.incidents.filter((i) => ['At risk', 'Breached'].includes(statusOf(i).label));
  const breached = data.incidents.filter((i) => statusOf(i).label === 'Breached').length;
  const completed = data.incidents.filter((i) => statusOf(i).label === 'Completed').length;
  const applicable = data.incidents.filter((i) => statusOf(i).label !== 'Not applicable').length;
  const compliance = applicable ? Math.round(((applicable - breached) / applicable) * 100) : 100;
  return (
    <main className="page">
      <section className="hero-panel">
        <div className="hero-kicker">SLA governance / live operational view</div>
        <h2>Keep service promises visible before they turn into escalations.</h2>
        <p>One focused workspace for triaging P1 risk, documenting breach context, and giving every incident manager a clear next move.</p>
        <Link href="/chat" className="button button-primary" data-testid="link-open-virtual-agent">Open Virtual Agent <ArrowRight size={15} /></Link>
      </section>
      <div className="metric-grid">
        <Metric label="Total incidents" value={data.incidents.length} meta={`${completed} completed`} icon={Activity} />
        <Metric label="Active SLA risk" value={risks.length} meta="P1 incidents at or over 75%" icon={AlertTriangle} tone="warning" />
        <Metric label="Breached SLAs" value={breached} meta="Needs justification" icon={AlertCircle} tone="danger" />
        <Metric label="Compliance" value={`${compliance}%`} meta="Applicable P1 population" icon={ShieldCheck} tone="success" />
      </div>
      <div className="two-col">
        <section className="panel panel-pad">
          <div className="section-head" style={{ marginTop: 0 }}><div><h3>Attention queue</h3><p>Incidents that need a decision now</p></div><Link href="/incidents" className="button button-quiet" data-testid="link-view-all-incidents">View register <ArrowRight size={14} /></Link></div>
          {risks.length === 0 ? <div className="empty-state"><CheckCircle2 className="empty-icon" /><strong>No active SLA risk</strong><p>The queue is clear. Keep monitoring the register.</p></div> : <div className="risk-list">{risks.slice(0, 4).map((incident) => {
            const status = statusOf(incident);
            return <div className="risk-row" key={incident.number} data-testid={`row-risk-${incident.number}`}><div><div className="incident-code">{incident.number}</div><Tag tone={status.tone}>{status.label}</Tag></div><div><div className="risk-title">{incident.desc}</div><div className="risk-meta">{incident.group} · {incident.assignee}</div></div><div className="risk-time">{status.label === 'Breached' ? `+${status.remaining?.toFixed(1)}h` : `${status.remaining?.toFixed(1)}h left`}</div></div>;
          })}</div>}
        </section>
        <section className="panel panel-pad">
          <div className="section-head" style={{ marginTop: 0 }}><div><h3>Governance pulse</h3><p>Policy signals for this demo</p></div><Settings2 size={17} color="hsl(var(--muted-foreground))" /></div>
          <div className="mini-kpi"><span>P1 SLA target</span><strong>04:00 hrs</strong></div>
          <div className="mini-kpi"><span>At-risk trigger</span><strong>75%</strong></div>
          <div className="mini-kpi"><span>Justifications open</span><strong>{data.justifications.filter((j) => j.review === 'Pending').length}</strong></div>
          <div className="notice" style={{ marginTop: 17 }}>The assistant can read this local register and route you to the right control.</div>
        </section>
      </div>
      <div className="section-head"><div><h2>How the control works</h2><p>A simple operating rhythm for every P1 incident.</p></div></div>
      <section className="panel panel-pad">
        <div className="process">
          {['Incident created', 'SLA monitoring', '75% warning', 'SLA breach', 'Justification', 'Manager review'].map((label, index, items) => <div className="process-step" key={label}><div className="process-node">{String(index + 1).padStart(2, '0')}</div><div className="process-label">{label}</div>{index < items.length - 1 && <div className="process-line" />}</div>)}
        </div>
      </section>
    </main>
  );
}

function IncidentsPage({ data, update }: { data: DemoData; update: (data: DemoData) => void }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ desc: '', priority: '1', group: 'Service Desk', assignee: 'Demo User', elapsed: '0', state: 'In Progress' });
  const [filter, setFilter] = useState('All');
  const filtered = data.incidents.filter((incident) => filter === 'All' || statusOf(incident).label === filter);
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!form.desc.trim()) return;
    const next: DemoData = { ...data, next: data.next + 1, incidents: [...data.incidents, { number: `INC001${data.next}`, desc: form.desc.trim(), priority: Number(form.priority), group: form.group.trim() || 'Service Desk', assignee: form.assignee.trim() || 'Demo User', elapsed: Math.max(0, Number(form.elapsed) || 0), state: form.state }] };
    update(next);
    setForm({ desc: '', priority: '1', group: 'Service Desk', assignee: 'Demo User', elapsed: '0', state: 'In Progress' });
    setShowForm(false);
  };
  const toggleResolved = (number: string) => update({ ...data, incidents: data.incidents.map((i) => i.number === number ? { ...i, state: i.state === 'Resolved' ? 'In Progress' : 'Resolved' } : i) });
  const remove = (number: string) => update({ ...data, incidents: data.incidents.filter((i) => i.number !== number), justifications: data.justifications.filter((j) => j.incident !== number) });
  return (
    <main className="page">
      <PageHeading eyebrow="Operational register" title="Incidents & SLA" subhead="Monitor the P1 clock, spot the 75% warning line, and keep ownership visible across the service desk." action={<button className="button button-primary" onClick={() => setShowForm(!showForm)} data-testid="button-add-incident"><Plus size={15} /> Add incident</button>} />
      {showForm && <form className="panel panel-pad mb-5" onSubmit={submit} data-testid="form-create-incident"><div className="section-head" style={{ marginTop: 0 }}><div><h3>New incident</h3><p>Use this to seed a local scenario or record a live handoff.</p></div><button type="button" className="icon-button" onClick={() => setShowForm(false)} aria-label="Close form" data-testid="button-close-incident-form"><X size={15} /></button></div><div className="form-grid"><div className="field full"><label htmlFor="incident-description">Short description</label><input id="incident-description" value={form.desc} onChange={(e) => setForm({ ...form, desc: e.target.value })} placeholder="Critical production application issue" data-testid="input-incident-description" required /></div><div className="field"><label htmlFor="incident-priority">Priority</label><select id="incident-priority" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })} data-testid="select-incident-priority"><option value="1">P1 — Critical</option><option value="2">P2 — High</option><option value="3">P3 — Moderate</option></select></div><div className="field"><label htmlFor="incident-state">State</label><select id="incident-state" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} data-testid="select-incident-state"><option>In Progress</option><option>Resolved</option></select></div><div className="field"><label htmlFor="incident-group">Assignment group</label><input id="incident-group" value={form.group} onChange={(e) => setForm({ ...form, group: e.target.value })} data-testid="input-incident-group" /></div><div className="field"><label htmlFor="incident-assignee">Assignee</label><input id="incident-assignee" value={form.assignee} onChange={(e) => setForm({ ...form, assignee: e.target.value })} data-testid="input-incident-assignee" /></div><div className="field"><label htmlFor="incident-elapsed">Hours already elapsed</label><input id="incident-elapsed" type="number" min="0" max="12" step=".1" value={form.elapsed} onChange={(e) => setForm({ ...form, elapsed: e.target.value })} data-testid="input-incident-elapsed" /><span className="field-hint">P1 target is 4 hours. Other priorities are not applicable.</span></div><div className="field flex justify-end"><button className="button button-primary self-start" type="submit" data-testid="button-create-incident"><Check size={15} /> Create incident</button></div></div></form>}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3"><div className="inline-form">{['All', 'At risk', 'Breached', 'Completed', 'Not applicable'].map((item) => <button key={item} onClick={() => setFilter(item)} className={`button ${filter === item ? 'button-primary' : 'button-secondary'}`} style={{ padding: '7px 10px', fontSize: 11 }} data-testid={`filter-incidents-${item.toLowerCase().replace(/\s/g, '-')}`}>{item}</button>)}</div><span className="text-xs text-muted-foreground">{filtered.length} of {data.incidents.length} records</span></div>
      <section className="panel table-shell" data-testid="table-incidents"><table><thead><tr><th>Incident</th><th>Description</th><th>Priority</th><th>Owner</th><th>SLA progress</th><th>Status</th><th>Action</th></tr></thead><tbody>{filtered.length === 0 ? <tr><td colSpan={7}><div className="empty-state"><CheckCircle2 className="empty-icon" /><strong>Nothing in this view</strong><p>Try another status filter.</p></div></td></tr> : filtered.map((incident) => { const status = statusOf(incident); return <tr key={incident.number} data-testid={`row-incident-${incident.number}`}><td><div className="incident-code">{incident.number}</div><div className="text-[11px] text-muted-foreground mt-1">{incident.assignee}</div></td><td><div className="font-semibold text-[12px]">{incident.desc}</div><div className="text-[11px] text-muted-foreground mt-1">{incident.group}</div></td><td><Tag tone={incident.priority === 1 ? 'danger' : 'neutral'}>P{incident.priority}</Tag></td><td className="text-xs">{incident.group}</td><td><div className="flex items-center gap-2"><div className="progress-track"><div className={`progress-fill ${status.tone === 'warning' ? 'warning' : status.tone === 'danger' ? 'danger' : ''}`} style={{ width: `${Math.min(status.pct, 100)}%` }} /></div><span className="font-mono text-[10px]">{status.pct}%</span></div></td><td><Tag tone={status.tone}>{status.label}</Tag><div className="text-[10px] text-muted-foreground mt-1">{incident.state}</div></td><td><div className="flex items-center gap-1"><button className="button button-quiet" onClick={() => toggleResolved(incident.number)} data-testid={`button-toggle-${incident.number}`}>{incident.state === 'Resolved' ? 'Reopen' : 'Resolve'}</button><button className="icon-button" onClick={() => remove(incident.number)} aria-label={`Delete ${incident.number}`} data-testid={`button-delete-${incident.number}`}><Trash2 size={14} /></button></div></td></tr>; })}</tbody></table></section>
    </main>
  );
}

function BreachesPage({ data, update }: { data: DemoData; update: (data: DemoData) => void }) {
  const breached = data.incidents.filter((i) => statusOf(i).label === 'Breached');
  const [form, setForm] = useState({ incident: breached[0]?.number ?? '', reason: 'Technical Complexity', explanation: '' });
  useEffect(() => { if (!form.incident && breached[0]) setForm((current) => ({ ...current, incident: breached[0].number })); }, [breached, form.incident]);
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!form.incident || !form.explanation.trim()) return;
    update({ ...data, justifications: [...data.justifications, { incident: form.incident, reason: form.reason, explanation: form.explanation.trim(), submittedBy: 'SLA User', review: 'Pending' }] });
    setForm({ ...form, explanation: '' });
  };
  const review = (index: number, value: string) => update({ ...data, justifications: data.justifications.map((item, itemIndex) => itemIndex === index ? { ...item, review: value } : item) });
  return (
    <main className="page">
      <PageHeading eyebrow="Accountability trail" title="Breach justifications" subhead="Capture the operating context behind every P1 miss. Submitted records stay local to this demo and remain available after reload." action={<Tag tone="danger">Mandatory for breaches</Tag>} />
      <div className="two-col">
        <form className="panel panel-pad" onSubmit={submit} data-testid="form-submit-justification"><div className="section-head" style={{ marginTop: 0 }}><div><h3>Submit a justification</h3><p>Be specific enough for a manager to review without a follow-up.</p></div><FileText size={18} color="hsl(var(--primary))" /></div>{breached.length === 0 ? <div className="notice">There are no breached P1 incidents right now. The form will activate when an incident crosses four hours.</div> : <div className="form-grid"><div className="field"><label htmlFor="justification-incident">Breached incident</label><select id="justification-incident" value={form.incident} onChange={(e) => setForm({ ...form, incident: e.target.value })} data-testid="select-justification-incident">{breached.map((incident) => <option key={incident.number} value={incident.number}>{incident.number} — {incident.desc}</option>)}</select></div><div className="field"><label htmlFor="justification-reason">Breach reason</label><select id="justification-reason" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} data-testid="select-justification-reason">{['Vendor Delay', 'Resource Unavailable', 'Technical Complexity', 'Customer Unavailable', 'Incorrect Assignment', 'Dependency', 'Major Outage', 'Other'].map((reason) => <option key={reason}>{reason}</option>)}</select></div><div className="field full"><label htmlFor="justification-explanation">Detailed explanation <span className="text-[hsl(var(--danger))]">*</span></label><textarea id="justification-explanation" value={form.explanation} onChange={(e) => setForm({ ...form, explanation: e.target.value })} placeholder="Explain the timeline, dependency, and recovery action..." data-testid="input-justification-explanation" required /><span className="field-hint">A useful justification names the cause, customer impact, and prevention step.</span></div><div className="field full"><button className="button button-primary self-start" type="submit" data-testid="button-submit-justification"><ClipboardCheck size={15} /> Submit for review</button></div></div>}</form>
        <section className="panel panel-pad"><div className="section-head" style={{ marginTop: 0 }}><div><h3>Review guidance</h3><p>Use a consistent decision trail.</p></div><ShieldCheck size={18} color="hsl(var(--primary))" /></div><div className="risk-list"><div className="risk-row" style={{ gridTemplateColumns: '28px 1fr' }}><div className="process-node">01</div><div><div className="risk-title">Name the cause</div><div className="risk-meta">Vendor, dependency, assignment, or technical constraint.</div></div></div><div className="risk-row" style={{ gridTemplateColumns: '28px 1fr' }}><div className="process-node">02</div><div><div className="risk-title">Describe the impact</div><div className="risk-meta">State what was delayed and who was affected.</div></div></div><div className="risk-row" style={{ gridTemplateColumns: '28px 1fr' }}><div className="process-node">03</div><div><div className="risk-title">Close the loop</div><div className="risk-meta">Include the prevention or follow-up action.</div></div></div></div></section>
      </div>
      <div className="section-head"><div><h2>Submitted records</h2><p>Manager review status for every justification.</p></div><span className="text-xs text-muted-foreground">{data.justifications.length} submitted</span></div>
      <section className="panel table-shell" data-testid="table-justifications"><table><thead><tr><th>Incident</th><th>Reason</th><th>Explanation</th><th>Submitted by</th><th>Manager review</th></tr></thead><tbody>{data.justifications.length === 0 ? <tr><td colSpan={5}><div className="empty-state"><ClipboardCheck className="empty-icon" /><strong>No justifications yet</strong><p>Submitted breach context will appear here.</p></div></td></tr> : data.justifications.map((item, index) => <tr key={`${item.incident}-${index}`} data-testid={`row-justification-${index}`}><td><div className="incident-code">{item.incident}</div></td><td><Tag tone="info">{item.reason}</Tag></td><td className="max-w-[330px] leading-relaxed">{item.explanation}</td><td>{item.submittedBy}</td><td><select className="rounded-lg border bg-card px-2 py-2 text-xs" value={item.review} onChange={(e) => review(index, e.target.value)} data-testid={`select-review-${index}`}><option>Pending</option><option>Approved</option><option>Needs revision</option></select></td></tr>)}</tbody></table></section>
    </main>
  );
}

function DashboardPage({ data }: { data: DemoData }) {
  const stats = useMemo(() => {
    const statuses = data.incidents.map(statusOf);
    return { completed: statuses.filter((s) => s.label === 'Completed').length, risk: statuses.filter((s) => s.label === 'At risk').length, breached: statuses.filter((s) => s.label === 'Breached').length };
  }, [data.incidents]);
  const reasons = useMemo(() => Object.entries(data.justifications.reduce<Record<string, number>>((acc, item) => { acc[item.reason] = (acc[item.reason] ?? 0) + 1; return acc; }, {})), [data.justifications]);
  const groups = useMemo(() => Object.entries(data.incidents.filter((i) => statusOf(i).label === 'Breached').reduce<Record<string, number>>((acc, item) => { acc[item.group] = (acc[item.group] ?? 0) + 1; return acc; }, {})), [data.incidents]);
  const maxReason = Math.max(1, ...reasons.map(([, value]) => value));
  const maxGroup = Math.max(1, ...groups.map(([, value]) => value));
  return (
    <main className="page">
      <PageHeading eyebrow="Governance signals" title="SLA dashboard" subhead="A compact readout of completion, exposure, and the quality of your breach review trail." action={<Link href="/incidents" className="button button-secondary" data-testid="link-dashboard-register">Open incident register <ArrowRight size={14} /></Link>} />
      <div className="metric-grid"><Metric label="Completed" value={stats.completed} meta="Resolved incidents" icon={CheckCircle2} tone="success" /><Metric label="At risk" value={stats.risk} meta="Between 75% and 100%" icon={Clock3} tone="warning" /><Metric label="Breached" value={stats.breached} meta="Over the 4-hour target" icon={AlertCircle} tone="danger" /><Metric label="Justifications" value={data.justifications.length} meta="Submitted records" icon={ClipboardCheck} /></div>
      <div className="three-col">
        <section className="panel panel-pad"><div className="section-head" style={{ marginTop: 0 }}><div><h3>Breach reasons</h3><p>Submitted explanation mix</p></div><BarChart3 size={17} color="hsl(var(--primary))" /></div>{reasons.length === 0 ? <div className="empty-state"><strong>No reason data</strong><p>Submit a justification to build this view.</p></div> : reasons.map(([name, value]) => <div className="bar-row" key={name}><span className="truncate">{name}</span><div className="bar-track"><div className="bar-fill danger" style={{ width: `${(value / maxReason) * 100}%` }} /></div><strong>{value}</strong></div>)}</section>
        <section className="panel panel-pad"><div className="section-head" style={{ marginTop: 0 }}><div><h3>Breached groups</h3><p>Where exposure is concentrated</p></div><Activity size={17} color="hsl(var(--primary))" /></div>{groups.length === 0 ? <div className="empty-state"><CheckCircle2 className="empty-icon" /><strong>No group exposure</strong><p>There are no breached groups to report.</p></div> : groups.map(([name, value]) => <div className="bar-row" key={name}><span className="truncate">{name}</span><div className="bar-track"><div className="bar-fill warning" style={{ width: `${(value / maxGroup) * 100}%` }} /></div><strong>{value}</strong></div>)}</section>
        <section className="panel panel-pad"><div className="section-head" style={{ marginTop: 0 }}><div><h3>Policy summary</h3><p>Rules active in this workspace</p></div><ShieldCheck size={17} color="hsl(var(--primary))" /></div><div className="mini-kpi"><span>P1 target</span><strong>4 hours</strong></div><div className="mini-kpi"><span>Warning at</span><strong>75%</strong></div><div className="mini-kpi"><span>Resolved</span><strong>Completed</strong></div><div className="mini-kpi"><span>P2 / P3</span><strong>Not applicable</strong></div></section>
      </div>
      <div className="section-head"><div><h2>Governance process</h2><p>Each handoff leaves a visible signal for the next role.</p></div></div>
      <section className="panel panel-pad"><div className="process">{['Created', 'Monitor', 'Warn at 75%', 'Breach', 'Justify', 'Review'].map((label, index, items) => <div className="process-step" key={label}><div className={`process-node ${index === 3 ? 'bg-[#fbe5e3] text-[#a43d36]' : ''}`}>{index + 1}</div><div className="process-label">{label}</div>{index < items.length - 1 && <div className="process-line" />}</div>)}</div></section>
      <div className="footer-note">Control Desk · Local governance demo · No external services connected</div>
    </main>
  );
}

function assistantReply(input: string, data: DemoData): { text: string; links?: { label: string; href: string }[] } {
  const q = input.toLowerCase();
  const number = input.match(/inc\d{7}/i)?.[0].toUpperCase();
  const breached = data.incidents.filter((item) => statusOf(item).label === 'Breached');
  const risk = data.incidents.filter((item) => statusOf(item).label === 'At risk');
  const completed = data.incidents.filter((item) => statusOf(item).label === 'Completed');
  const applicable = data.incidents.filter((item) => statusOf(item).label !== 'Not applicable');
  const compliance = applicable.length ? Math.round(((applicable.length - breached.length) / applicable.length) * 100) : 100;
  const link = (label: string, href: string) => ({ label, href });
  const isExplanation = ['what is', 'what are', 'explain', 'define', 'meaning', 'how does', 'tell me about', 'why does'].some((phrase) => q.includes(phrase));
  const asksList = ['show', 'list', 'which', 'what work', 'what incidents', 'give me'].some((phrase) => q.includes(phrase));

  if (number) {
    const incident = data.incidents.find((item) => item.number === number);
    if (!incident) return { text: `I could not find ${number} in the local incident register. The demo currently contains ${data.incidents.length} incidents. Check the incident number or open the register to see the available records.`, links: [link('Open incident register', '/incidents')] };
    const status = statusOf(incident);
    const timing = status.label === 'Breached'
      ? `${status.remaining?.toFixed(1)} hours over the 4-hour target`
      : status.label === 'At risk'
        ? `${status.remaining?.toFixed(1)} hours remain before breach`
        : status.label === 'Completed'
          ? 'the incident is resolved and the SLA is complete'
          : status.label === 'Not applicable'
            ? 'this priority is outside the P1 SLA policy'
            : `${status.remaining?.toFixed(1)} hours remain in the target`;
    const nextStep = status.label === 'Breached' ? 'Next step: submit a breach justification for manager review.' : status.label === 'At risk' ? 'Next step: keep the owner engaged and act before the remaining time expires.' : status.label === 'Completed' ? 'Next step: retain the record for governance reporting.' : 'Next step: continue monitoring the incident.';
    return { text: `${incident.number} is ${status.label.toLowerCase()}.\n\nDescription: ${incident.desc}\nPriority: P${incident.priority}${incident.priority === 1 ? ' — Critical' : incident.priority === 2 ? ' — High' : ' — Moderate'}\nOwner: ${incident.assignee}\nAssignment group: ${incident.group}\nState: ${incident.state}\nSLA progress: ${incident.priority === 1 ? `${incident.elapsed.toFixed(1)} of 4.0 hours elapsed (${status.pct}%)` : 'Not applicable for P2/P3 under this demo policy'}\nTiming: ${timing}\n\n${nextStep}`, links: [link('Inspect incident', '/incidents'), ...(status.label === 'Breached' ? [link('Justify breach', '/breaches')] : [])] };
  }

  if (q.includes('hello') || q.includes('hi') || q.includes('help') || q === 'hey' || q.includes('what can you do')) {
    return { text: `I am the SLA Governance Virtual Agent. I can explain this project and read the local incident register.\n\nAsk me to:\n• Check SLA for an incident, such as INC0010001\n• List breached, at-risk, completed, or all incidents\n• Explain incidents, SLAs, breaches, risk warnings, or justifications\n• Walk through the full governance process\n• Explain the dashboard, compliance, or manager review\n• Tell you how to create an incident or submit a justification\n\nTry: “Explain the project workflow” or “List breached or at-risk work”.`, links: [link('Open incident register', '/incidents'), link('Open dashboard', '/dashboard')] };
  }

  if (isExplanation && (q.includes('project') || q.includes('workflow') || q.includes('step') || q.includes('process') || q.includes('work'))) {
    return { text: `This project is a local SLA governance workspace for service desk managers. Its purpose is to make time risk visible, create an accountability trail, and help a manager decide what to do next.\n\nThe project flow is:\n1. Incident created — record the issue, priority, group, assignee, elapsed hours, and state.\n2. SLA monitoring — the workspace calculates progress against the 4-hour P1 target.\n3. 75% warning — a P1 incident becomes at risk at 3 hours, so the owner has a chance to act before breach.\n4. SLA breach — once a P1 reaches 4 hours, it is marked breached and appears in the attention queue.\n5. Justification — document the cause, impact, and prevention or follow-up action.\n6. Manager review — a reviewer marks the explanation Pending, Approved, or Needs revision.\n7. Dashboard reporting — the workspace summarizes completion, exposure, breach reasons, groups, and compliance.\n\nAll records are demo data saved in this browser, so this build does not require a network connection.`, links: [link('View overview', '/'), link('Open dashboard', '/dashboard')] };
  }

  if (isExplanation && (q.includes('incident') || q.includes('ticket'))) {
    return { text: 'An incident is a record of a service issue that needs ownership and resolution. In this project it includes a number, short description, priority, assignment group, assignee, elapsed hours, and state. The incident is the object whose SLA clock is monitored. Create one from Incidents & SLA, then resolve or reopen it as the work changes.', links: [link('Create or view incidents', '/incidents')] };
  }

  if (isExplanation && (q.includes('sla') || q.includes('service level') || q.includes('time target'))) {
    return { text: 'An SLA, or service-level agreement, is the time target for handling a service commitment. This demo applies a 4-hour target to P1 critical incidents. It calculates elapsed time as a percentage of that target: below 75% is within SLA, 75% through 99% is at risk, and 100% or more is breached. P2 and P3 records are shown, but their SLA status is Not applicable in this policy.', links: [link('Open SLA register', '/incidents'), link('View policy dashboard', '/dashboard')] };
  }

  if (isExplanation && (q.includes('breach') || q.includes('missed'))) {
    return { text: 'An SLA breach happens when a P1 incident reaches or exceeds the 4-hour target before it is resolved. A breach is a governance signal, not just a red status: it means the team must explain what prevented timely resolution. The incident stays visible in the register, and a breach justification should be submitted for manager review.', links: [link('See breached work', '/incidents'), link('Submit justification', '/breaches')] };
  }

  if (isExplanation && (q.includes('risk') || q.includes('warning') || q.includes('at-risk') || q.includes('at risk'))) {
    return { text: 'At risk means a P1 incident has used at least 75% of its 4-hour SLA but has not breached yet. In practice, that is 3 hours or more elapsed. It is an early warning to contact the owner, remove blockers, and make progress before the deadline. Resolved and non-P1 incidents are excluded from the active risk count.', links: [link('Open at-risk work', '/incidents')] };
  }

  if (isExplanation && (q.includes('priority') || q.includes('p1') || q.includes('p2') || q.includes('p3'))) {
    return { text: 'Priority describes the urgency of an incident. P1 is Critical and is governed by the 4-hour SLA in this demo. P2 is High and P3 is Moderate; they remain in the register but are Not applicable to the P1 SLA calculation. Resolved incidents are marked Completed regardless of priority.', links: [link('View incident register', '/incidents')] };
  }

  if (isExplanation && (q.includes('justif') || q.includes('reason') || q.includes('manager review'))) {
    return { text: 'A breach justification is the written explanation for why a P1 SLA was missed. A strong justification has three parts:\n1. Cause — name the vendor, dependency, resource, assignment, technical issue, or outage.\n2. Impact — explain what was delayed and who or what was affected.\n3. Close the loop — state the recovery, prevention, or follow-up action.\n\nChoose the breached incident, select a reason, write the explanation, and submit it. The record starts as Pending; a manager can mark it Approved or Needs revision.', links: [link('Start a justification', '/breaches')] };
  }

  if (q.includes('list') || q.includes('show') || q.includes('which') || q.includes('work')) {
    const asksBreached = q.includes('breach') || q.includes('overdue') || q.includes('missed');
    const asksRisk = q.includes('risk') || q.includes('warning') || q.includes('at-risk') || q.includes('at risk');
    if (asksBreached || asksRisk) {
      const sections = [
        ...(asksBreached ? [`Breached (${breached.length}): ${breached.length ? breached.map((item) => `${item.number} — ${item.desc} (${item.elapsed.toFixed(1)}h elapsed)`).join('; ') : 'none'}`] : []),
        ...(asksRisk ? [`At risk (${risk.length}): ${risk.length ? risk.map((item) => `${item.number} — ${item.desc} (${statusOf(item).pct}% used)`).join('; ') : 'none'}`] : []),
      ];
      return { text: `${sections.join('\n')}\n\nBreached work needs a justification. At-risk work needs action before the remaining SLA time expires.`, links: [link('Open incident register', '/incidents'), ...(breached.length ? [link('Submit a justification', '/breaches')] : [])] };
    }
    if (q.includes('all') || q.includes('incident') || q.includes('register')) {
      return { text: data.incidents.length ? `The register contains ${data.incidents.length} incidents:\n${data.incidents.map((item) => `${item.number} — ${statusOf(item).label} — ${item.desc}`).join('\n')}` : 'The incident register is empty. Create an incident to start monitoring SLA work.', links: [link('Open incident register', '/incidents')] };
    }
  }

  if (q.includes('dashboard') || q.includes('summary') || q.includes('metric') || q.includes('compliance') || q.includes('report')) {
    return { text: `Dashboard summary:\n• Total incidents: ${data.incidents.length}\n• Completed: ${completed.length}\n• At risk: ${risk.length}\n• Breached: ${breached.length}\n• Submitted justifications: ${data.justifications.length}\n• Compliance: ${compliance}% of applicable P1 work is not breached\n\nThe dashboard also groups submitted justifications by reason and breached incidents by assignment group. The policy is P1 = 4 hours, warning at 75%, resolved = Completed, and P2/P3 = Not applicable.`, links: [link('Open dashboard', '/dashboard')] };
  }

  if (q.includes('create') || q.includes('add') || q.includes('new incident')) {
    return { text: 'To create an incident, open Incidents & SLA and choose Add incident. Enter a short description, priority, assignment group, assignee, elapsed hours, and state. For a P1, the elapsed hours immediately determine whether the record is Within SLA, At risk, or Breached. The record is saved locally and appears in the overview and dashboard.', links: [link('Create an incident', '/incidents')] };
  }

  if (q.includes('save') || q.includes('persist') || q.includes('local') || q.includes('demo') || q.includes('network')) {
    return { text: 'This is a zero-backend demo. Incidents, justifications, and this conversation are stored in your browser using local storage. Refreshing the page keeps them on this device. The data is not shared with another browser or connected to ServiceNow, and there is no external network connection required.', links: [link('Open overview', '/')] };
  }

  if (q.includes('review') || q.includes('approve') || q.includes('pending')) {
    return { text: 'Manager review is the final control in the governance process. Every submitted justification starts as Pending. On the Justifications page, a reviewer can mark it Approved when the explanation is sufficient or Needs revision when the cause, impact, or follow-up action is not clear enough.', links: [link('Review justifications', '/breaches')] };
  }

  return { text: `Here is how this SLA project works: incidents are created, P1 SLA time is monitored against a 4-hour target, a 75% warning identifies at-risk work, a 100% threshold identifies breaches, and every breach can be justified and reviewed. I can also answer questions about the dashboard, compliance, priorities, local demo data, or a specific incident.\n\nI did not find a data-specific answer for that wording, so try asking: “What is a breach?”, “Explain every step of the project”, “List breached or at-risk work”, or “Check SLA for INC0010001”.`, links: [link('View overview', '/'), link('Open Virtual Agent', '/chat')] };
}

function ChatPage({ data }: { data: DemoData }) {
  const [messages, setMessages] = useState<Message[]>(() => {
    try { const saved = localStorage.getItem(CHAT_KEY); return saved ? JSON.parse(saved) as Message[] : [{ id: 1, role: 'assistant', text: 'Welcome to the SLA Governance Virtual Agent. I can read the local incident register and help you decide what needs attention.' }]; } catch { return [{ id: 1, role: 'assistant', text: 'Welcome to the SLA Governance Virtual Agent. I can read the local incident register and help you decide what needs attention.' }]; }
  });
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);
  useEffect(() => { localStorage.setItem(CHAT_KEY, JSON.stringify(messages)); bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);
  const send = (text = input) => { const clean = text.trim(); if (!clean) return; const answer = assistantReply(clean, data); setMessages((current) => [...current, { id: Date.now(), role: 'user', text: clean }, { id: Date.now() + 1, role: 'assistant', text: answer.text, links: answer.links }]); setInput(''); };
  const quickActions = [{ label: 'Check SLA for INC0010001', icon: Clock3 }, { label: 'List breached or at-risk work', icon: AlertTriangle }, { label: 'Explain the project workflow', icon: FileText }, { label: 'How do I justify a breach?', icon: ClipboardCheck }, { label: 'Show dashboard summary', icon: BarChart3 }];
  return (
    <main className="page">
      <PageHeading eyebrow="Decision support" title="Virtual Agent" subhead="Ask in plain language. The assistant answers from this browser's incident register and routes you to the action." />
      <div className="chat-layout">
        <aside className="panel panel-pad"><div className="flex items-center gap-3"><div className="brand-mark" style={{ width: 35, height: 35 }}><Bot size={17} /></div><div><h3 style={{ marginBottom: 2 }}>Quick actions</h3><span className="text-[10px] text-muted-foreground">Common control questions</span></div></div><div className="quick-list">{quickActions.map(({ label, icon: Icon }) => <button className="quick-action" key={label} onClick={() => send(label)} data-testid={`button-quick-${label.toLowerCase().replace(/[^a-z]+/g, '-')}`}><Icon />{label}</button>)}</div><div className="notice" style={{ marginTop: 17 }}>Demo mode: responses use local incident and justification data. No network connection is required.</div></aside>
        <section className="panel chat-shell" data-testid="chat-shell"><div className="chat-head"><div><strong>SLA Governance Virtual Agent</strong><div className="text-[11px] text-[#b8d0d1] mt-1">Register-aware guidance for service desk managers</div></div><div className="chat-online"><span className="status-dot" />ONLINE</div></div><div className="chat-messages" data-testid="chat-messages">{messages.map((message) => <div className={`chat-message ${message.role === 'user' ? 'user' : ''}`} key={message.id} data-testid={`message-${message.role}-${message.id}`}><div className="message-avatar">{message.role === 'user' ? 'SU' : 'VA'}</div><div><div className="message-bubble">{message.text}</div>{message.links && <div className="flex flex-wrap gap-2 mt-2">{message.links.map((link) => <Link key={link.href + link.label} href={link.href} className="button button-secondary" style={{ padding: '6px 9px', fontSize: 10 }} data-testid={`link-chat-${link.label.toLowerCase().replace(/[^a-z]+/g, '-')}`}>{link.label} <ArrowRight size={11} /></Link>)}</div>}</div></div>)}<div ref={bottomRef} /></div><form className="chat-compose" onSubmit={(event) => { event.preventDefault(); send(); }}><input value={input} onChange={(event) => setInput(event.target.value)} placeholder="Ask about SLA status, risk, breaches, or the dashboard..." aria-label="Message the virtual agent" data-testid="input-chat-message" /><button className="button button-primary" type="submit" data-testid="button-send-message"><Send size={14} /> Send</button></form></section>
      </div>
    </main>
  );
}

function Router() {
  const { data, update } = useDemoData();
  return <Shell><ErrorBoundary resetKey={location.pathname}><Switch><Route path="/"><HomePage data={data} /></Route><Route path="/chat"><ChatPage data={data} /></Route><Route path="/incidents"><IncidentsPage data={data} update={update} /></Route><Route path="/breaches"><BreachesPage data={data} update={update} /></Route><Route path="/dashboard"><DashboardPage data={data} /></Route><Route component={NotFound} /></Switch></ErrorBoundary></Shell>;
}

const queryClient = new QueryClient();

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;